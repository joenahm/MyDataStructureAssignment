/* 
	Author	:	Joe Nahm
	Email	:	joenahm@yeah.net
 */
#ifndef _DG_ELEM_TYPE_
#define _DG_ELEM_TYPE_

typedef char dg_elem_type;

#endif
