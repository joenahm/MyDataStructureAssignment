/* 
	Author	:	Joe Nahm
	Email	:	joenahm@yeah.net
 */
#ifndef _QUEUE_ELEM_TYPE_H_
#define _QUEUE_ELEM_TYPE_H_

typedef int queue_elem_type; //change it into the type you want

#endif