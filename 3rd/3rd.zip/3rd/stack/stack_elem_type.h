/* 
	Author	:	Joe Nahm
	Email	:	joenahm@yeah.net
 */
#ifndef _STACK_ELEM_TYPE_H_
#define _STACK_ELEM_TYPE_H_

#include "../binary-tree/tbt_elem_type.h"

typedef TBTNode* elem_type;	//change it into the type you want

#endif